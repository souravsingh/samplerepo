#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import dateutil
from datetime import datetime
from dateutil import relativedelta
from warnings import filterwarnings
filterwarnings('ignore')


# In[2]:


import keras
from keras.models import load_model
from platform import python_version

def cust2_loss(y_actual,y_predicted):
    custom_loss1= np.sum(((y_actual-y_predicted)/y_actual))
    return tf.where((custom_loss1 > 0), (np.abs(1 * custom_loss1)), (np.abs(1.5 * custom_loss1)))


# In[3]:


print("Python Version", python_version())
print('Pandas Version', pd.__version__)
print('Numpy Version', np.__version__)
print('dateutil Version', dateutil.__version__)
print('keras Version', keras.__version__)


# In[4]:


loc = get_ipython().getoutput('pwd')


# In[5]:


#REQUIRED FUNCTIONS
def convert_datetime(df, columns):
    for c in columns:
        df[c+"_PREPROCESSED"] = pd.to_datetime(df[c], format='%d%m%Y')
    return df

#function to convert string date column into datetime64
def convert_datetime1(x):
    try:
        return datetime.strptime(x, '%d%m%Y')
    except:
        return None

def truncate_datetime_check(x):
    if x.day == 1:
        return x
    else:
        return x + pd.offsets.MonthBegin(-1)
def truncate_datetime(df, columns):
    for c in columns:
        df[c+'_TRUNCATED'] = df[c].apply(lambda x: truncate_datetime_check(x))
    return df
def month_difference(d1, d2):
#     print(d1, d2)
    try:
        delta = relativedelta.relativedelta(d1, d2)
        return delta.months + (delta.years * 12)
    except:
        return None
def print_to_csv(dataframe, filename):
    dataframe.to_csv(loc[0]+'/' + filename + '.csv', index=False)


# In[6]:


def check_tradeline_openclose(date_closed, date_processed):
    if (not pd.isnull(date_closed)) and (date_closed <= date_processed):
        return "Closed"
    elif (not pd.isnull(date_closed)) and (date_closed > date_processed):
        return "Open"
    elif (pd.isnull(date_closed)):
        return "Open"

def check_tradeline_openclose_3yrs(Acct_open_Diff, date_closed, Close_dt_Diff):
    if (pd.isnull(date_closed)) and (Acct_open_Diff > 6):
        return 1
    elif (not pd.isnull(date_closed)) and (Acct_open_Diff > 6) and (Close_dt_Diff <= 36):
        return 1
    elif (not pd.isnull(date_closed)) and (Acct_open_Diff > 6) and (Close_dt_Diff > 36):
        return 1
    elif (not pd.isnull(Acct_open_Diff)) and (Acct_open_Diff <= 6):
        return 1
    else:
        return None

def check_low_vintage_tradeline(Acct_open_Diff):
    if (not pd.isnull(Acct_open_Diff)) and (Acct_open_Diff <= 6):
        return 1
    else:
        return 0
    
def cibil_hit_flag(bureau_TL,Low_vint_TL):
    if (bureau_TL) > (Low_vint_TL):
        return "Hit-6+ Vintage"
    elif (bureau_TL) == (Low_vint_TL):
        return "Hit-lt 6 Vintage"
    else:
        return None
    
def cibil_hit_flag_2(x):
    if (pd.isnull(x)):
        return "NOHIT"
    else:
        return "HIT"
def cast_func_int(x):
    if (pd.isnull(x)):
        return None
    else:
        return int(x)
    
def all_livelimit_to_vintage1(x, y):
    if pd.isnull(y):
        return 0
    elif y == 0:
        return 0
    else:
        return x/y


# In[7]:


def create_app_cibil_sangam(df1,df2, CIBIL_PRODUCT_CODES):
    df1 = df1.merge(df2, on= ['MEMBERREFERENCE'], how = 'inner').drop(['ENQUIRYCONTROLNUMBER_y', 'DATEPROCESSED_y'], axis=1).rename(columns={'ENQUIRYCONTROLNUMBER_x': 'ENQUIRYCONTROLNUMBER', 'DATEPROCESSED_x':'DATEPROCESSED'})
    cols = ["DATEPROCESSED", "DATEOPENEDDISBURSED", "DATEREPORTED_TRADES", "DATEOFLASTPAYMENT", "DATECLOSED"]
    df1 = convert_datetime(df1, cols)
    df1['ACCOUNT_TYPE_CODE'] = df1['ACCOUNT_TYPE_CODE'].astype('int')
    CIBIL_PRODUCT_CODES = CIBIL_PRODUCT_CODES.rename(columns = {"acct_type_code": "ACCOUNT_TYPE_CODE"})
    CIBIL_PRODUCT_CODES['ACCOUNT_TYPE_CODE'] = CIBIL_PRODUCT_CODES['ACCOUNT_TYPE_CODE'].astype('int')
    df1 = df1.merge(CIBIL_PRODUCT_CODES, on='ACCOUNT_TYPE_CODE', how='left')
    cols = ["DATEPROCESSED_PREPROCESSED", "DATEOPENEDDISBURSED_PREPROCESSED", 
        "DATEREPORTED_TRADES_PREPROCESSED","DATEOFLASTPAYMENT_PREPROCESSED", "DATECLOSED_PREPROCESSED"]
    df1 = truncate_datetime(df1, cols)
    df1['Acct_open_Diff'] = df1[['DATEPROCESSED_PREPROCESSED_TRUNCATED', 'DATEOPENEDDISBURSED_PREPROCESSED_TRUNCATED']].apply(lambda x: month_difference(x['DATEPROCESSED_PREPROCESSED_TRUNCATED'], x['DATEOPENEDDISBURSED_PREPROCESSED_TRUNCATED']),axis=1)
    df1['last_pay_Diff'] = df1[['DATEPROCESSED_PREPROCESSED_TRUNCATED', 'DATEOFLASTPAYMENT_PREPROCESSED_TRUNCATED']].apply(lambda x: month_difference(x['DATEPROCESSED_PREPROCESSED_TRUNCATED'], x['DATEOFLASTPAYMENT_PREPROCESSED_TRUNCATED']),axis=1)
    df1['Close_dt_Diff'] = df1[['DATEPROCESSED_PREPROCESSED_TRUNCATED', 'DATECLOSED_PREPROCESSED_TRUNCATED']].apply(lambda x: month_difference(x['DATEPROCESSED_PREPROCESSED_TRUNCATED'], x['DATECLOSED_PREPROCESSED_TRUNCATED']),axis=1)
    truncated_cols = ['DATEPROCESSED_PREPROCESSED_TRUNCATED', 
             'DATEOPENEDDISBURSED_PREPROCESSED_TRUNCATED', 'DATEREPORTED_TRADES_PREPROCESSED_TRUNCATED',
            'DATEOFLASTPAYMENT_PREPROCESSED_TRUNCATED', 'DATECLOSED_PREPROCESSED_TRUNCATED']
    df1 = df1.drop(columns = truncated_cols, axis = 1)
    df1['OPEN_TL'] = df1[['DATECLOSED_PREPROCESSED', 'DATEPROCESSED_PREPROCESSED']].apply(lambda x: check_tradeline_openclose(x['DATECLOSED_PREPROCESSED'], x['DATEPROCESSED_PREPROCESSED']), axis=1)    
    df1['TL_tb_consdrd'] = df1[['Acct_open_Diff', 'DATECLOSED_PREPROCESSED', 'Close_dt_Diff']].apply(lambda x: check_tradeline_openclose_3yrs(x['Acct_open_Diff'], x['DATECLOSED_PREPROCESSED'], x['Close_dt_Diff']), axis=1)    
    df1['Low_vint_TL'] = df1['Acct_open_Diff'].apply(lambda x: check_low_vintage_tradeline(x))    
    return df1

def get_cibil_flag(sy_turf_tl, base_data):
    cibil_hit = sy_turf_tl.groupby('MEMBERREFERENCE').agg({'TL_tb_consdrd':'sum', 'Low_vint_TL': 'sum'}).rename(columns={'TL_tb_consdrd': 'bureau_TL', 'Low_vint_TL':'Low_vint_TL'})
    cibil_hit_tl = cibil_hit.loc[cibil_hit['bureau_TL'] > 0].reset_index()
    cibil_flag = cibil_hit_tl[["bureau_TL", "Low_vint_TL"]].apply(lambda x: cibil_hit_flag(x['bureau_TL'], x['Low_vint_TL']), axis=1)
    cibil_flag = pd.concat([cibil_hit_tl['MEMBERREFERENCE'], cibil_flag],axis=1).rename(columns={0: 'Flag'})
    base_data = base_data.merge(cibil_flag, on=['MEMBERREFERENCE'], how='left')
    return base_data

def show_hit_rate(base_data):
    base_data['CIBIL_FLAG_24M'] = base_data['Flag'].apply(lambda x: cibil_hit_flag_2(x))
    return base_data


# In[8]:


def create_cibil_pl1( sy_turf_tl ,condition = None, months = 6, prd = 'all'):
    df = sy_turf_tl
    df['HIGH_CREDIT_SANCTIONED_AMOUNT'] = df['HIGHCREDITSANCTIONEDAMOUNT'].apply(lambda x: cast_func_int(x))
    df['CURRENT_BALANCE'] = df['CURRENTBALANCE'].apply(lambda x: cast_func_int(x))
    df = df[df.acct_prd.isin(condition)]
    mask_open_tl = df['DATECLOSED_PREPROCESSED'].isna()
    df.loc[mask_open_tl, 'open_tl'] = 1
    df.loc[~mask_open_tl, 'open_tl'] = None
    mask_closed_tl1 = ~df['DATECLOSED_PREPROCESSED'].isna()
    mask_closed_tl2 = df['DATECLOSED_PREPROCESSED'] < df['DATEPROCESSED_PREPROCESSED']
    df['TL'] = 1
    df.loc[((mask_closed_tl1)&(mask_closed_tl2)),'closed_tl'] = 1
    df.loc[~((mask_closed_tl1)&(mask_closed_tl2)),'closed_tl'] = None
    mask_open_TL_as_on1 = df['Acct_open_Diff'] > months
    mask_open_TL_as_on2 = df['DATECLOSED_PREPROCESSED'].isna()
    mask_open_TL_as_on3 = df['Close_dt_Diff'] <= months
    df.loc[((mask_open_TL_as_on1) & ((mask_open_TL_as_on2) | (mask_open_TL_as_on3))), 'open_TL_as_on'] = 1
    df.loc[~((mask_open_TL_as_on1) & ((mask_open_TL_as_on2) | (mask_open_TL_as_on3))), 'open_TL_as_on'] = None
    mask_closed_TL_as_on1 = ~df['DATECLOSED_PREPROCESSED'].isna()
    mask_closed_TL_as_on2 = df['Close_dt_Diff'] >= months
    df.loc[((mask_closed_TL_as_on1) & (mask_closed_TL_as_on2)), 'Closed_TL_as_on'] = 1
    df.loc[~((mask_closed_TL_as_on1) & (mask_closed_TL_as_on2)), 'Closed_TL_as_on'] = None
    df['Age_of_trade'] = df['Acct_open_Diff'].apply(lambda x: cast_func_int(x))
    mask_No_of_TL_open_last_month1 = df['Acct_open_Diff'] > 0
    mask_No_of_TL_open_last_month2 = df['Acct_open_Diff'] <= months
    df.loc[((mask_No_of_TL_open_last_month1) & (mask_No_of_TL_open_last_month2)), 'No_of_TL_open_last_'+str(months)+'_month'] = 1
    df.loc[~((mask_No_of_TL_open_last_month1) & (mask_No_of_TL_open_last_month2)), 'No_of_TL_open_last_'+str(months)+'_month'] = None
    mask_No_of_TL_close_last_month1 = ~df['DATECLOSED_PREPROCESSED'].isna()
    mask_No_of_TL_close_last_month2 = df['Close_dt_Diff'] <= months
    df.loc[((mask_No_of_TL_close_last_month1) & mask_No_of_TL_close_last_month2), 'No_of_TL_close_last_'+str(months)+'_month'] = 1
    df.loc[~((mask_No_of_TL_close_last_month1)&(mask_No_of_TL_close_last_month2)), 'No_of_TL_close_last_'+str(months)+'_month'] = None
    return df


# In[9]:


def create_summary(df,months = 6, prd = "All"):
    summary = df
    mask_Act_vintage_on_bureau = (df['open_tl'] == 1)
    summary.loc[(mask_Act_vintage_on_bureau), prd+'_Act_vintage_on_bureau'] = summary['Acct_open_Diff']
    summary.loc[~(mask_Act_vintage_on_bureau), prd+'_Act_vintage_on_bureau'] = 0
    mask_Ind_Open_TL = (df['OWNERSHIPINDICATOR'] == '1')
    summary.loc[(mask_Ind_Open_TL), prd+'_Ind_Open_TL'] = summary['open_tl']
    summary.loc[~(mask_Ind_Open_TL), prd+'_Ind_Open_TL'] = 0
    mask_live_limit = (df['open_tl'] == 1)
    summary.loc[(mask_live_limit), prd+'_live_limit'] = df['HIGH_CREDIT_SANCTIONED_AMOUNT']
    summary.loc[~(mask_live_limit), prd+'_live_limit'] = 0
    mask_Ind_limit_last_month1 = (df['OWNERSHIPINDICATOR'] == '1')
    mask_Ind_limit_last_month2 = (df['Acct_open_Diff'] <= months)
    summary.loc[((mask_Ind_limit_last_month1)&(mask_Ind_limit_last_month2)), prd+'_Ind_limit_last_'+str(months)+'_month']=df['HIGH_CREDIT_SANCTIONED_AMOUNT']
    summary.loc[~((mask_Ind_limit_last_month1)&(mask_Ind_limit_last_month2)), prd+'_Ind_limit_last_'+str(months)+'_month']=0
    
    summary_grouped = summary.groupby('MEMBERREFERENCE').agg({
        'TL': 'sum',
        'open_tl': 'sum',
        'Acct_open_Diff': 'max',
        prd+'_Act_vintage_on_bureau': 'max',
        prd+'_Ind_Open_TL': 'sum',
        'HIGH_CREDIT_SANCTIONED_AMOUNT': 'sum',
        prd+'_live_limit': 'sum',
        'CURRENT_BALANCE': 'sum',
        prd+'_Ind_limit_last_'+str(months)+'_month':'sum',
        
    }).rename(columns={
        'TL': prd+'_No_of_TL',
        'open_tl': prd+'_open_TL',
        'Acct_open_Diff': prd+'_Vin_bureau',
        prd+'_Act_vintage_on_bureau':prd+'_Act_vintage_on_bureau',
        prd+'_Ind_Open_TL': prd+'_Ind_Open_TL',
        'HIGH_CREDIT_SANCTIONED_AMOUNT': prd+'_limit',
        prd+'_live_limit':prd+'_live_limit',
        'CURRENT_BALANCE': prd+'_balance',
        prd+'_Ind_limit_last_'+str(months)+'_month': prd+'_Ind_limit_last_'+str(months)+'_mnth',
    })
    return summary_grouped.reset_index()
def create_final_data(base_data,sy_turf_tl,condition = None,month = 6, product = 'All'):
    cibil_pl1 = create_cibil_pl1(sy_turf_tl, condition, month, product)
    summary = create_summary(cibil_pl1,month,product)
    base_columns = base_data.columns
    summary_cols = summary.columns
    to_delete_cols = []
    for col in base_columns:
        if col in summary_cols:
            if(col != 'MEMBERREFERENCE'):
                to_delete_cols.append(col)
    if len(to_delete_cols):
        summary = summary.drop(columns = to_delete_cols, axis = 1)
    base_data = base_data.merge(summary, on = ['MEMBERREFERENCE'], how = 'left')
    return base_data


# # Feature Creation

# In[10]:


df_TL = pd.read_csv(loc[0]+'/FinalCustData.csv', dtype=str, encoding='utf-8')
df_TL = df_TL.drop(['ENQUIRYCONTROLNUMBER.1'],axis=1)
df_TL['INT_SCORE'] = df_TL['INT_SCORE'].astype('int')
df_TL = df_TL[df_TL.INT_SCORE>-1]
df_customers = pd.read_csv(loc[0]+'/100_sample_data_v1.csv',dtype=str, encoding='utf-8')
CIBIL_PRODUCT_CODES = pd.read_csv(loc[0]+'/CIBIL_PRODUCT_CODES_N.csv')


# In[11]:


df_unique = df_customers[['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER', 'DATEPROCESSED']].drop_duplicates(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER','DATEPROCESSED'])
df_unique1 = df_unique.merge(df_TL.groupby('MEMBERREFERENCE').agg({
    'OCCUPATION_CODE_FINAL': 'min',
    'AGE': 'min',
    'INT_SCORE': 'max'
}).reset_index(), on='MEMBERREFERENCE', how='left')
df_unique1['AGE'] = df_unique1['AGE'].fillna(0).astype('int')
df_unique1['INT_SCORE'] = df_unique1['INT_SCORE'].fillna(0).astype('int')
df_unique1['OCCUPATION_CODE_FINAL'] = df_unique1['OCCUPATION_CODE_FINAL'].fillna(0).astype('int')
mask_hit = ((df_unique1['INT_SCORE'] == 0) | (df_unique1['INT_SCORE'] == -1))
df_unique1.loc[mask_hit, 'FLAG_HIT_NOHIT'] = 'NOHIT'
df_unique1.loc[~mask_hit, 'FLAG_HIT_NOHIT'] = 'HIT'
df_unique1['DATEPROCESSED'] = df_unique1['DATEPROCESSED'].apply(lambda x: convert_datetime1(x))


# In[12]:


CIBIL_PRODUCT_CODES.loc[CIBIL_PRODUCT_CODES['acct_type_code'] == 17, 'acct_prd'] = 'CV'
CIBIL_PRODUCT_CODES.loc[CIBIL_PRODUCT_CODES['acct_type_code'] == 17, 'tl_category'] = 'Sec_Oth'
CIBIL_PRODUCT_CODES.loc[CIBIL_PRODUCT_CODES['acct_type_code'] == 33, 'acct_prd'] = 'CE'
CIBIL_PRODUCT_CODES.loc[CIBIL_PRODUCT_CODES['acct_type_code'] == 33, 'tl_category'] = 'Sec_Oth'
CIBIL_PRODUCT_CODES = CIBIL_PRODUCT_CODES.astype('str')


# In[13]:


mask_N_Mort = (CIBIL_PRODUCT_CODES['acct_type_code'].isin(['1','5','8','17','13','15','51','52','53','54','15','4','6','7','9','32','33','34']))
list_N_Mort = list(CIBIL_PRODUCT_CODES.loc[(mask_N_Mort), 'acct_prd'])
prd_2_cond_py = {
        'All': CIBIL_PRODUCT_CODES.acct_prd.unique(),
              'CC':['CC'],
             'PL': ['PL'],
             'AL': ['AL'],
             'HL': ['HL'],
             'LAP': ['LAP'],
             'CL': ['Cons_Ln'],
             'BL': ['BL_Gen', 'BL_PSL'],
             'TWL': ['TWL'],
             'GL':['GL'],
             'CV_CE': ['CV', 'CE'],
             'Usec_C': ['PL', 'CC'],
             'Sec_C': ['HL', 'LAP', 'AL'],
             'Usec_O': ['Cons_Ln', 'Edu_Ln', 'other', 'OD'],
             'Sec_O': ['LAS', 'GL', 'TWL', 'CV','CE','TRL', 'BL_PSL', 'BL_Gen'],
             'SEC': ['LAS', 'GL', 'TWL', 'CV','CE','TRL','HL','LAP','AL','BL_PSL','BL_Gen'],
             'USEC': ['Cons_Ln', 'Edu_Ln', 'other', 'OD', 'PL', 'CC'],
             'HL_LAP': ['HL', 'LAP'],
             'AL_HL': ['HL', 'AL'],
             'PL_CL': ['PL', 'Cons_Ln'],
             'SD': ['LAP', 'GL', 'LAS'],
             'WH_PER': ['AL','TWL'],
             'WH_COM': ['TRL', 'CV', 'CE'],
             'WHEELS': ['AL', 'TWL','TRL', 'CV', 'CE'],
            'PL_BLN': ['PL', 'BL_PSL', 'BL_Gen'],
    
    
            'PL_BLN2': ['PL', 'BL_PSL', 'BL_Gen'],
            'CC_ODN': ['CC','OD'],
            'CC_ODN2': ['CC','OD'],
            'USEC_N2': ['Cons_Ln','Edu_Ln','Other','OD','PL','CC'],
    
    
            'REGN': ['AL', 'HL', 'LAP', 'PL', 'Cons_Ln', 'BL_PSL', 'BL_Gen', 'GL'],
            'SP': ['HL', 'AL', 'TWL'],
            'N_Mort': list_N_Mort
}


# In[14]:


base_data = df_unique
TL_data = df_TL
APP_cibil_sangam = create_app_cibil_sangam(base_data, TL_data, CIBIL_PRODUCT_CODES)
sy_turf_tl = APP_cibil_sangam.loc[(APP_cibil_sangam['OWNERSHIPINDICATOR'].isin(['1', '4', ''])) & (APP_cibil_sangam['Acct_open_Diff']>=0)]
base_data = get_cibil_flag(sy_turf_tl, base_data)
base_data = show_hit_rate(base_data)


# In[15]:


products = ['PL','CC', 'BL', 'Sec_C', 'Sec_O', 'USEC',
            'Usec_C', 'Usec_O', 'All', 'CC_ODN', 
            'SP', 'REGN', 'N_Mort', 'PL_BLN', 
            'WH_PER', 'WHEELS']
months = [6,12, 24, 36]
for prd in products:
    for month in months:
        base_data = create_final_data(base_data,sy_turf_tl,month = month,condition = prd_2_cond_py[prd], product = prd) 

base_data['all_livelimit_to_vintage1']= base_data[['All_live_limit', 'All_Act_vintage_on_bureau']].apply(lambda x: all_livelimit_to_vintage1(x['All_live_limit'], x['All_Act_vintage_on_bureau']), axis=1)


# In[16]:


base_data2 = df_unique
mask_sy_turf_tl2 = (sy_turf_tl['OCCUPATION_CODE_FINAL'] == '1')
mask_sy_turf_tl21 = (sy_turf_tl['acct_prd'].isin(['OD', 'LAP', 'BL_PSL', 'BL_Gen', 'GL']))
sy_turf_tl2 = sy_turf_tl[~(mask_sy_turf_tl2 & mask_sy_turf_tl21)]
base_data2 = get_cibil_flag(sy_turf_tl2, base_data2)
base_data2 = show_hit_rate(base_data2)


# In[17]:


products = ['PL_BLN2', 'CC_ODN2', 'USEC_N2']
months = [6]
for prd in products:
    for month in months:
        base_data2 = create_final_data(base_data2,sy_turf_tl2,month = month,condition = prd_2_cond_py[prd], product = prd)        


# In[18]:


mask_upgrade1 = (sy_turf_tl2['acct_prd'] == 'CC')
mask_upgrade2 = (sy_turf_tl2['acct_prd'] == 'PL')
mask_upgrade3 = (sy_turf_tl2['acct_prd'] == 'AL')
mask_upgrade4 = (sy_turf_tl2['acct_prd'] == 'HL')

sy_turf_tl2.loc[(mask_upgrade1), 'upgrade_1'] = 1
sy_turf_tl2.loc[(mask_upgrade2), 'upgrade_1'] = 2
sy_turf_tl2.loc[(mask_upgrade3), 'upgrade_1'] = 3
sy_turf_tl2.loc[(mask_upgrade4), 'upgrade_1'] = 4

sy_turf_tl2.loc[(mask_upgrade1), 'upgrade_11'] = 1
sy_turf_tl2.loc[(mask_upgrade2), 'upgrade_11'] = 2
sy_turf_tl2.loc[(mask_upgrade3), 'upgrade_11'] = 3
sy_turf_tl2.loc[(mask_upgrade4), 'upgrade_11'] = 4

extra1 = sy_turf_tl2.groupby('MEMBERREFERENCE').agg({
    'upgrade_1': 'max',
    'upgrade_11': 'min'
}).rename(columns = {
    'upgrade_1': 'max_upgrade_1',
    'upgrade_11': 'min_upgrade_1'
})
extra2 = extra1
extra2['loan_upgrade'] = extra2['max_upgrade_1'] - extra2['min_upgrade_1']
mask_loan_upgrade_flag = (extra2['loan_upgrade'] > 0)
extra2.loc[(mask_loan_upgrade_flag), 'loan_upgrade_flag'] = 1
extra2.loc[~(mask_loan_upgrade_flag), 'loan_upgrade_flag'] = 0
mask_upgrade_unsec2sec1 = (extra2['max_upgrade_1'].isin([3, 4]))
mask_upgrade_unsec2sec2 = (extra2['min_upgrade_1'].isin([1, 2]))
extra2.loc[((mask_upgrade_unsec2sec1) & (mask_upgrade_unsec2sec2)), 'loan_upgrade_unsec2sec'] = 1
extra2.loc[~((mask_upgrade_unsec2sec1) & (mask_upgrade_unsec2sec2)), 'loan_upgrade_unsec2sec'] = 0
extra2 = extra2[['loan_upgrade_unsec2sec']].reset_index()


# In[19]:


base_data2 = base_data2.merge(extra2, on = ['MEMBERREFERENCE'], how = 'left')
relevant_cols = ['MEMBERREFERENCE', 'PL_BLN2_Act_vintage_on_bureau', 'PL_BLN2_live_limit', 'USEC_N2_limit', 'CC_ODN2_limit', 'loan_upgrade_unsec2sec']


# In[20]:


base_data_final = base_data.merge(base_data2[relevant_cols], on = ['MEMBERREFERENCE'], how = 'left')


# In[21]:


final_features = [
    'MEMBERREFERENCE',
    
    
    'PL_BLN2_Act_vintage_on_bureau',
    'SP_Act_vintage_on_bureau',
    'REGN_Act_vintage_on_bureau', 
    
    'Usec_C_balance',
    
    'N_Mort_Ind_limit_last_12_mnth',
    'All_Ind_limit_last_12_mnth',
    'PL_Ind_limit_last_12_mnth',

    'Sec_C_Ind_Open_TL',

    'USEC_N2_limit',
    'CC_ODN2_limit',
    'N_Mort_limit',
    'PL_limit',
    'WH_PER_limit',
    'SP_limit',
    'REGN_limit',
    'PL_BLN_limit',
    'WHEELS_limit',
    
    'PL_BLN2_live_limit',
    'CC_live_limit',
    'USEC_live_limit',
    'N_Mort_live_limit',
    
    'CC_ODN_No_of_TL',
    'All_No_of_TL',
    'SP_No_of_TL',
    
    'CC_Vin_bureau',
    'All_Vin_bureau',
    'Usec_O_Vin_bureau',
    'Sec_O_Vin_bureau',
    'Sec_C_Vin_bureau',
    'PL_Vin_bureau',
    
    'all_livelimit_to_vintage1',
    
    'loan_upgrade_unsec2sec',
    
    'All_open_TL'

]
base_data_final_f = base_data_final[final_features]
base_data_final_f = base_data_final_f.merge(df_unique1, on='MEMBERREFERENCE', how='left')


# In[22]:


for c in base_data_final_f.columns:
    base_data_final_f[c] = base_data_final_f[c].fillna(0)


# # Feature Standardization

# In[23]:


df_lookup = pd.read_csv(loc[0]+'/GEN2_Standardization.csv')


# In[24]:


base_data_final_ff = base_data_final_f[[
    'CC_Vin_bureau', 'CC_live_limit', 'PL_BLN2_live_limit', 'N_Mort_limit',
       'PL_limit', 'USEC_live_limit', 'WH_PER_limit', 'Usec_C_balance',
       'SP_limit', 'All_No_of_TL', 'CC_ODN_No_of_TL', 'USEC_N2_limit',
       'all_livelimit_to_vintage1', 'OCCUPATION_CODE_FINAL', 'AGE', 'REGN_limit',
       'CC_ODN2_limit', 'All_Vin_bureau', 'SP_No_of_TL', 'All_open_TL',
       'Usec_O_Vin_bureau', 'Sec_O_Vin_bureau', 'Sec_C_Vin_bureau',
       'N_Mort_Ind_limit_last_12_mnth', 'PL_BLN_limit', 'N_Mort_live_limit',
       'All_Ind_limit_last_12_mnth', 'PL_Ind_limit_last_12_mnth',
       'WHEELS_limit', 'Sec_C_Ind_Open_TL', 'PL_BLN2_Act_vintage_on_bureau',
       'loan_upgrade_unsec2sec', 'SP_Act_vintage_on_bureau',
       'REGN_Act_vintage_on_bureau', 'PL_Vin_bureau', 'MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER','DATEPROCESSED',  'INT_SCORE',
                                           'FLAG_HIT_NOHIT']]


# In[25]:


base_data_final_f = base_data_final_f.drop(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER','DATEPROCESSED',  'INT_SCORE',
                                           'FLAG_HIT_NOHIT'],axis = 1) 
outlier_dict = list(df_lookup['Outlier'])
mean_dict = list(df_lookup['Mean'])
sd_dict = list(df_lookup['Std'])


# In[26]:


idx = 0
for var in base_data_final_f.columns:
    base_data_final_f[var] = np.where((base_data_final_f[var]>outlier_dict[idx]),outlier_dict[idx],base_data_final_f[var])
    base_data_final_f[var] = (base_data_final_f[var] - mean_dict[idx])/sd_dict[idx]
    idx+=1


# In[27]:


# data = []
# tmp = []
# idx=1
# for c in df_val.columns:
#     if idx%5==0:
#         tmp.append(df_val[c][0])
#         data.append(tmp)
#         tmp = []
#     else:
#         tmp.append(df_val[c][0])
#     idx+=1
#     print(c)
# print_to_csv(pd.DataFrame(data, columns=['Outlier', 'Mean', 'Std', 'Min', 'Max']), 'GEN2_Standardization')


# # Model Execution

# In[28]:


model1 = load_model('IENTBGEN2_PLCC_Model_File.h5',
                    custom_objects={'cust2_loss':cust2_loss},  
                    compile=False)


# In[29]:


#Input: Standardized Dataset
output_pr1 = model1.predict_proba(base_data_final_f)
output1 = pd.DataFrame(output_pr1,columns = ['preds'])
final = output1

final["MEMBERREFERENCE"] = base_data_final_ff["MEMBERREFERENCE"].values
final["ENQUIRYCONTROLNUMBER"] = base_data_final_ff["ENQUIRYCONTROLNUMBER"].values
final["DATEPROCESSED"] = base_data_final_ff["DATEPROCESSED"].values
final["AGE"] = base_data_final_ff["AGE"].values
final["OCCUPATION_CODE_FINAL"] = base_data_final_ff["OCCUPATION_CODE_FINAL"].values
final["FLAG_HIT_NOHIT"] = base_data_final_ff["FLAG_HIT_NOHIT"].values


print_to_csv(final, 'Predictions')


# In[ ]:




