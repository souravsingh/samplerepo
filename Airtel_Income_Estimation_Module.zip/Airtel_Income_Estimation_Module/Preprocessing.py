#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pwd')


# In[2]:


loc = get_ipython().getoutput('pwd')
loc[0]


# In[3]:


#Importing Relevant Libraries
import datetime
import pandas as pd
import re
pd.set_option("display.max_rows", None)
from datetime import datetime
import numpy as np
from platform import python_version
import pkg_resources

print("Python Version", python_version())
print('Pandas Version', pd.__version__)
print('re Version', re.__version__)
print('Numpy Version', np.__version__)


# In[4]:


#RELEVANT FUNCTION
#function to remove em dash code
def remove_emdash(x):
    return x.replace('( – )','',regex=True)

#function to convert string date column into datetime64
def convert_datetime(x):
    return datetime.strptime(x, '%d%m%Y')

def print_to_csv(dataframe, filename):
    dataframe.to_csv(loc[0]+ '/' + filename + '.csv', index=False)

#function to remove all the special characters and spaces from the Account Type Description 
#in the Mapping Master provided by Airtel 
def string_preprocessing(x):
    try:
        return re.sub('[^A-Za-z0-9+]', '', x).upper()
    except:
        return x

#function to convert string cibil score column into integer column
def cibil_score_conversion(x):
    if x == "000-1":
        return -1
    elif pd.isnull(x) == True:
        return 0
    else:
        return int(x)
#function to pick customers whose 
def occupation_code_final(x):
    if x == True:
        return 1
    else:
        return 0
#function to convert days to years
def convert_to_years(x):
    tmp = x.days/365
    if tmp < 0:
        return 0
    else:
        return tmp
#function for finding difference between two dates
def date_difference(x, y):
    return x-y


# In[5]:


#Importing Relevant Tables


#1.Airtel 100 Customers Sample
#2.Mapping Master File
#3.Occupation Code Mapping Master


df_customers = pd.read_csv(loc[0]+'/100_sample_data_v1.csv',dtype=str, encoding='utf-8')
df_dummy_mapping_master= pd.read_csv(loc[0]+'/Axis_Manually_Adjusted_Account_Type_Master.csv',dtype=str, encoding='utf-8')
df_occupation_code_master = pd.read_csv(loc[0]+'/Occupation_Master_Airtel_Shared_By_Cibil.csv',dtype=str, encoding='utf-8')


# In[6]:


#Creating set of unique customers on the basis of MEMBERREFERENCE and ENQUIRYCONTROLNUMBER
df_unique = df_customers[['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER']].drop_duplicates(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER'])


# # CIBIL Score Master 

# In[7]:


#CIBIL_SCORE_MASTER
#selecting only those rows which have SCORENAME = CIBILTUSC3
#and selecting only the revelant columns required
print("Original 100 customers file shape: ", df_customers.shape)
df_customers1 = df_customers[df_customers['SCORENAME'] == "CIBILTUSC3"]
df_customers1 = df_customers1[["ENQUIRYCONTROLNUMBER",  "MEMBERREFERENCE", "SCORENAME", "SCORECARDNAME", "SCORECARDVERSION", "SCORE"]]
print("After filtering and selecting relevant columns for cibil score master, shape is: ",df_customers1.shape)


# In[8]:


#CIBIL_SCORE_MASTER
#Passing the string score column through a function that applies required filters and passes out a integer value.
df_customers1['INT_SCORE'] = df_customers1['SCORE'].apply(lambda x: cibil_score_conversion(x))
#Groupby on EnquiryControlNumber and MemberReference and picking the minimum CIBIL score for each group inorder to be conservative
df_customers1 = df_customers1.groupby(['ENQUIRYCONTROLNUMBER', 'MEMBERREFERENCE']).min().reset_index()
# print_to_csv(df_customers1, 'CIBILMASTER')


# In[9]:


df_customers1.head()


# In[10]:


#TESTING CIBIL SCORE
# df_tmp = df_customers1
# df_tmp = df_tmp.append(pd.DataFrame([['002435985434', '5517666424284332435', 'CIBILTUSC3', '08', '10', '00800']],columns = df_tmp.columns))
# df_tmp['INT_SCORE'] = df_tmp['SCORE'].apply(lambda x: cibil_score_conversion(x))
# df_tmp.groupby(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER']).max()


# # AGE Master

# In[11]:


#AGE_MASTER
#Dropping NULL Values in Date Of Birth Type for Age Dataset
df_customers2 = df_customers.dropna(subset=['DATEOFBIRTH'])
print("Number of Total Values: {} and NULL Values in Date of Birth: {}".format(len(df_customers2.DATEOFBIRTH), sum(df_customers2.DATEOFBIRTH.isna())))


# In[12]:


#AGE_MASTER
#Selecting required columns for the age master
df_customers2 = df_customers2[["MEMBERREFERENCE", "ENQUIRYCONTROLNUMBER", "DATEOFBIRTH"]]


# In[13]:


#AGE_MASTER
df_customers3 = df_unique.merge(df_customers2, on='MEMBERREFERENCE', how='left')
df_customers3 = df_customers3.fillna(datetime.strptime('20500101', '%Y%m%d'))
df_customers3 = df_customers3.rename(columns={'ENQUIRYCONTROLNUMBER_x': 'ENQUIRYCONTROLNUMBER'})
df_customers3 = df_customers3.drop(['ENQUIRYCONTROLNUMBER_y'],axis = 1)


# In[14]:


#AGE_MASTER
#Converting string date column into datetime64
df_customers3['DATEOFBIRTHPREPROCESSED'] = df_customers3['DATEOFBIRTH'].apply(lambda x: convert_datetime(x))
#Dropping DATEOFBIRTH column for ease in groupby
df_customers3 = df_customers3.drop(['DATEOFBIRTH'],axis=1)
#Group by using MEMBERREFERENCE and ENQUIRYCONTROLNUMBER and for each group breaking ties by picking the youngest DATEOFBIRTH
df_customers3 = df_customers3.groupby(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER']).agg({'DATEOFBIRTHPREPROCESSED': np.max}).reset_index()
# print_to_csv(df_tmp, 'AGE_MASTER')


# In[15]:


df_customers3.head()


# In[16]:


# #TESTING
# df_tmp = df_customers3
# df_tmp = df_tmp.append(pd.DataFrame([['1146207568686369452', '001652369108', '25051964']],columns=['MEMBERREFERENCE','ENQUIRYCONTROLNUMBER','DATEOFBIRTH']))
# df_tmp['DATEOFBIRTHPREPROCESSED'] = df_tmp['DATEOFBIRTH'].apply(lambda x: convert_datetime(x))
# df_tmp = df_tmp.drop(['DATEOFBIRTH'],axis=1)
# # df_tmp.head(2)
# df_tmp = df_tmp.groupby(['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER']).agg({'DATEOFBIRTHPREPROCESSED': np.max}).reset_index()
# # print_to_csv(df_tmp, 'AGE_MASTER')
# df_tmp


# # Occupation Code Master 

# In[17]:


#OCCUPATION_CODE_MASTER
#Dropping null values in occupation code for occupation code dataset
df_customers4 = df_customers.dropna(subset=['OCCUPATION_CODE'])
print("Number of Total Values: {}, NULL Values in Account Type: {}".format(len(df_customers4.OCCUPATION_CODE),sum(df_customers4.OCCUPATION_CODE.isna())))


# In[18]:


#OCCUPATION_CODE_MASTER
#Picking relevant columns for the occupation_code master and grouping using MEMBERREFERENCE and ENQUIRYCONTROLNUMBER
#and for each group breaking ties by favouring Self-Employed over Salaried inorder to be conservative
df_customers4 = df_customers4[["MEMBERREFERENCE", "ENQUIRYCONTROLNUMBER", "OCCUPATION_CODE"]]
df_customers4 = df_customers4.groupby(["MEMBERREFERENCE", "ENQUIRYCONTROLNUMBER"]).max().reset_index()


# In[19]:


#OCCUPATION_CODE_MASTER


# Code	Description
# 1	Salaried
# 2	Self Employed Professional
# 3	Self Employed
# 4	Others


#Converting Code column in mapping master to int inorder for merging with the master file
df_occupation_code_master['Code'] = df_occupation_code_master['Code'].astype('int')
#Adding a column with Name matching with the master inorder for proper merging with the master file 
df_occupation_code_master['OCCUPATION_CODE'] = df_occupation_code_master['Code']
#Doing the same with the 100 customers master file for merging with the mapping master file
df_customers4.OCCUPATION_CODE = df_customers4.OCCUPATION_CODE.astype('int')
#Selecting Relevant columns and droping duplicated columns having same combination of MEMBERREFERENCE and ENQUIRYCONTROLNUMBER
#so that Occupation_Code of those customers can be filled whose Occupation_code is not provided
df_customers5 = df_unique.merge(df_customers4, on='MEMBERREFERENCE', how='left')


# In[20]:


#OCCUPATION_CODE_MASTER
#filling null values as 0
df_customers5 = df_customers5.fillna(0.0)
#removing extra columns which are not required
df_customers5 = df_customers5.rename(columns={'ENQUIRYCONTROLNUMBER_x':'ENQUIRYCONTROLNUMBER'})
df_customers5 = df_customers5.drop(['ENQUIRYCONTROLNUMBER_y'],axis = 1)


# In[21]:


#OCCUPATION_CODE_MASTER
#merging the resulting 100 customer master file with the occupation code master file inorder to get the description of the code
df_customers5 = df_customers5.merge(df_occupation_code_master, on='OCCUPATION_CODE', how='left')


# In[22]:


#OCCUPATION_CODE_MASTER
#creating a flag column which differentiates between Salaried customers and Self-Employeed customers
df_customers5['OCCUPATION_CODE_FLAG']=df_customers5.Description.str.upper().str.contains('SAL')


# In[23]:


#OCCUPATION_CODE_MASTER
#using the flag column to give final occupation code 1 to Salaried Customers and 4 to Self-Employeed customers
df_customers5['OCCUPATION_CODE_FINAL'] = df_customers5['OCCUPATION_CODE_FLAG'].apply(lambda x: occupation_code_final(x))
df_customers5.head()


# # TradeLine Master

# In[24]:


#TRADELINE MASTER
#passing the Description column in account type mapping master to a function to remove all the special characters and spaces 
#and converting them to upper case for ease in merging
df_dummy_mapping_master['ACCOUNTTYPEPREPROCESSED'] = df_dummy_mapping_master['Description'].apply(lambda x: string_preprocessing(x))
#passing the ACCOUNTTYPE column in 100 customers master to a function to remove all the special characters and spaces 
#and converting them to upper case for ease in merging
df_customers['ACCOUNTTYPEPREPROCESSED'] = df_customers['ACCOUNTTYPE'].apply(lambda x: string_preprocessing(x))


# In[25]:


#TRADELINE MASTER
#Dropping NULL Values in Account Type
df_customers6 = df_customers.dropna(subset=['ACCOUNTTYPE'])
print("Number of Total Values: {}, NULL Values in Account Type: {}".format(len(df_customers6['ACCOUNTTYPE']),sum(df_customers6.ACCOUNTTYPE.isna())))


# In[26]:


#TRADELINE MASTER
#Remove duplicate tradelines basis combination of ID, DateOpened, DateClosed, DateReported, PayHist_start_date, Balance, ProductType
#GIVEN BY ARYA
df_customers7 = df_customers6.drop_duplicates(['MEMBERREFERENCE','ENQUIRYCONTROLNUMBER','DATEPROCESSED','DATEOPENEDDISBURSED','DATECLOSED','DATEREPORTED_TRADES','PAY_HIST_START_DATE','CURRENTBALANCE','ACCOUNTTYPE'])
df_customers7.shape


# In[27]:


#TRADELINE_MASTER
#Merging the 100 customers master with the modified account type mapping master file
df_customers7 = df_customers7.merge(df_dummy_mapping_master, on='ACCOUNTTYPEPREPROCESSED', how='left')
# print_to_csv(df_customers3, 'TradelineFinalAirtelMaster')


# In[28]:


#Renaming columns
df_customers7 = df_customers7.rename(columns = {'Description': 'Axis_Manually_Adjusted__Master_ACCOUNTTYPE_DESCRIPTION'
                     , 'Code': 'ACCOUNT_TYPE_CODE'})


# In[29]:


#Converting account type code to int
df_customers7['ACCOUNT_TYPE_CODE'] = df_customers7['ACCOUNT_TYPE_CODE'].astype('int')
df_customers7.head()


# # Merging Tradeline Master with CIBIL Score Master, Age Master and Occupation Code Master

# In[30]:


#Finally merging the CIBIL Score Master, Age Master, Occupation Code Master with the Tradeline Master 
#on the basis of MEMBERREFERENCE
df_final = df_customers7
df_final = df_final.merge(df_customers1, on='MEMBERREFERENCE', how='left')
df_final = df_final.merge(df_customers3, on='MEMBERREFERENCE', how='left')
df_final = df_final.merge(df_customers5, on='MEMBERREFERENCE', how='left')


# In[31]:


#CIBIL_SCORE_MASTER ---- df_customers1
#AGE_MASTER ---- df_customers3
#OCCUPATION_CODE_MASTER ---- df_customers5
#TRADELINE_MASTER ---- df_customers7


# In[32]:


#Renaming columns and removing extra common columns
df_final = df_final.rename(columns={
    'ENQUIRYCONTROLNUMBER_y': 'ENQUIRYCONTROLNUMBER',
    'OCCUPATION_CODE_x': 'OCCUPATION_CODE',
    'SCORENAME_x': 'SCORENAME',
    'SCORECARDNAME_x': 'SCORECARDNAME',
    'SCORECARDVERSION_x': 'SCORECARDVERSION',
    'SCORE_x': 'SCORE'
})
df_final = df_final.drop(['ENQUIRYCONTROLNUMBER_x','SCORENAME_y', 'SCORECARDNAME_y', 'SCORECARDVERSION_y', 'SCORECARDVERSION_y', 'SCORE_y', 'Code', 'Description', 'OCCUPATION_CODE_FLAG', 'OCCUPATION_CODE_y'], axis=1)


# In[33]:


#Calculation the age of customer by converting date processed from string to datetime64 
#and finding the difference between dateofbirth and dateprocessed and replacing negative age(because of missing value in dateofbirth treatment) to 0
#and converting the age to int
#and dropping the extra columns
df_final['DATEPROCESSEDPREPROCESSED'] = df_final['DATEPROCESSED'].apply(lambda x: convert_datetime(x))

df_final['AGE'] = df_final[['DATEPROCESSEDPREPROCESSED', 'DATEOFBIRTHPREPROCESSED']].apply(lambda x: date_difference(x['DATEPROCESSEDPREPROCESSED'], x['DATEOFBIRTHPREPROCESSED']),axis=1)
df_final['AGE'] = df_final['AGE'].apply(lambda x: convert_to_years(x))
df_final['AGE'] = df_final['AGE'].astype('int')
df_final = df_final.drop(['DATEPROCESSEDPREPROCESSED'], axis=1)


# In[34]:


df_final.shape


# In[35]:


print_to_csv(df_final, "FinalCustData")


# In[36]:


#TESTING FOR NULL DATEOFBIRTH WHICH IS REPLACED BY 1-1-2050 TO CHECK IF THE NEGATIVE AGES ARE CONVERTING TO ZERO OR NOT
# df_final_tmp = df_final[['MEMBERREFERENCE', 'ENQUIRYCONTROLNUMBER', 'DATEOFBIRTHPREPROCESSED', 'DATEPROCESSED']]
# df_final_tmp['DATEPROCESSEDPREPROCESSED'] = df_final_tmp['DATEPROCESSED'].apply(lambda x: convert_datetime(x))
# df_final_tmp.at[0,'DATEOFBIRTHPREPROCESSED'] = datetime.strptime('20500101','%Y%m%d')
# df_final_tmp['AGE'] = df_final_tmp[['DATEPROCESSEDPREPROCESSED', 'DATEOFBIRTHPREPROCESSED']].apply(lambda x: date_difference(x['DATEPROCESSEDPREPROCESSED'], x['DATEOFBIRTHPREPROCESSED']),axis=1)
# df_final_tmp['AGE'] = df_final_tmp['AGE'].apply(lambda x: convert_to_years(x))
# df_final_tmp['AGE'] = df_final_tmp['AGE'].astype('int')
# df_final_tmp = df_final_tmp.drop(['DATEPROCESSEDPREPROCESSED'], axis=1)
# df_final_tmp


# In[ ]:




